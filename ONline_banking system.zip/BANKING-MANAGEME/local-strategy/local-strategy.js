								
passport.use(new LocalStrategy(									
  (username, password, done) => {									
    // Query to find user by username									
    db.query('SELECT * FROM users WHERE username = ?', [username], (err, results) => {									
      if (err) return done(err);									
      if (results.length === 0) return done(null, false, { message: 'Incorrect username.' });									
									
      const user = results[0];									
									
      // Verify password with bcrypt (using callback-style)									
      bcrypt.compare(password, user.password, (err, isMatch) => {									
        if (err) return done(err);									
        if (isMatch) {									
          return done(null, user);									
        } else {									
          return done(null, false, { message: 'Incorrect password.' });									
        }									
      });									
    });									
  }									
));									
									
// Serialize user into session									
passport.serializeUser((user, done) => {									
  done(null, user.id);									
});									
									
// Deserialize user from session									
passport.deserializeUser((id, done) => {									
  db.query('SELECT * FROM users WHERE id = ?', [id], (err, results) => {									
    if (err) return done(err);									
									
  })})