const express = require("express")
const app = express()
const session = require("express-session")
const ejs = require("ejs")
const passport = require('passport');						
const LocalStrategy = require('passport-local').Strategy;						
const bcrypt = require('bcryptjs')
const flash = require('connect-flash');
const bodyParser = require("body-parser")
const mysql = require("mysql")
const port = 3000



app.set("view engine", "ejs")
app.use(flash());
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended: true}))
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: false
}));
app.use(passport.initialize());
app.use(passport.session());

app.use((req, res, next) => {
    res.locals.success_msg = req.flash('success_msg');
    res.locals.messages = req.flash();
    res.locals.error = req.flash('error');
    next();
});


const connection = mysql.createConnection({
    host:'localhost',
    user:"root",
    password:"Doco0026",
    database: "customers"
})

connection.connect((err)=>{
    if (err){
        console.error("Error connecting to database")
        return;
    }
    console.log("Connected successfully");
    
});

app.get("/user/login", (req, res)=>{
    res.render("./logins/Userlogin.ejs")
})



/* */
app.get("/", (req, res)=>{
    res.redirect("/user/login")
})


app.get("/view", (req, res)=>{
    connection.query("SELECT * FROM customer",(err, results)=>{
        if(err){
            console.error(err)
        }
        console.log(results)
        res.render("viewCustomers",{results})
    })
    
})

app.get("/Adminview", (req, res)=>{
    connection.query("SELECT * FROM admin_table",(err, results)=>{
        if(err){
            console.error(err)
        }
        console.log(results)
        res.render("./adminDetail/viewAdmin",{results})
    })
    
})

app.get("/CreateCustomer", (req, res)=>{
    res.render("createCustomer")
})

app.get("/updateCustomer", (req, res)=>{
    connection.query("SELECT * FROM customer",(err, results)=>{
        if(err){
            console.error(err)
        }
        console.log(results)
        res.render("updateCustomer",{results})
    })
})

app.get("/createAdmin", (req, res)=>{
    res.render("./adminDetail/createAdmin")
})

app.get("/loginAdmin", (req, res)=>{
    res.render("./adminAuth/loginAdmin")
})

app.post("/createAdmin",(req, res) =>{
    const{surName,firstName,username,email,password } = req.body;
    bcrypt.hash(password, 10, (err, hashedPassword)=>{

        if(err){
            console.log("error hashing password",err)
            return;
        }  
        connection.query('INSERT INTO admin_table SET ?',{Surname:surName, username,firstName: firstName, email,password:hashedPassword,}, 
        (err, result)=>{
        if(err){
            console.error("erorr inserting data into admin databae", err)
            return;
        }
        console.log("succefully added admin data")
        res.redirect("/Adminview")
})})})

app.post("/updateCustomer",(req, res) =>{
    const {customer_id}  = req.body;
    const query = "SELECT * FROM customer WHERE Customer_id = ?";
    connection.query(query, [customer_id],(err, record)=>{
        if(err){
            console.error("erorr inserting data into databae", err)
            return;
        }
        res.render("updateCustomer", {record})
    })
})

app.get("/updateCustomer", (req, res)=>{
    connection.query("SELECT * FROM customer",(err, results)=>{
        if(err){
            console.error(err)
        }
        console.log(results)
        res.render("updateCustomer",{results})
    })
})


app.post("/viewCustomer",(req, res) =>{ 
    
    const{surName,firstName,email,password, phone,dob,HomeAddress,Amount,accountType } = req.body;
    bcrypt.hash(password, 10, (err, hashedPassword)=>{
        if(err){
            console.log("error hashing password",err)
            return;
        }  
    connection.query('INSERT INTO customer SET ?',{Surname:surName, firstName: firstName,  contact_Address:HomeAddress, email, password: hashedPassword, phone_number:phone, DOB:dob,balance: Amount, Account_type: accountType}, 
    (err, result)=>{
    if(err){
        console.error("erorr inserting data into databae", err)
        return;
    } 

    console.log("succefully added customer data")
    res.redirect("/")
})
})
})

app.post("/viewUpdatedCustomer",(req, res) =>{
    const UpdateQuery = 'UPDATE customer SET Surname = ?, firstname = ?, DOB = ?, password = ?, email = ?, contact_Address = ?, phone_Number = ?, Account_type = ?, Balance = ? WHERE Customer_id = ?';

    // Destructure the values from req.body (make sure to match the field names correctly)
    const { surName, firstName, dob, password, email, HomeAddress, phone, accountType, Amount, Customer_id } = req.body;
   
    // Ensure the values are passed in the correct order (matching the placeholders)
    
    connection.query(UpdateQuery, [surName,firstName,dob,password, email, HomeAddress, phone,accountType, Amount, Customer_id], (err, results) => {

    if (err) {
        console.error('Error updating the record', err);
    }
      console.log('Record updated successfully', results); 
      res.redirect("/")
    });
    
     
})

app.post("/deleteAll", (req, res)=>{
    const query = 'TRUNCATE TABLE customer'
    connection.query(query,(err, results)=>{
        if(err){
            console.error("erorr deleting all records", err)
            return;
        }
        console.log("Delected All Records Successfully")
        res.redirect("/view")
    })
    
})
app.post("/AdmindeleteAll", (req, res)=>{
    const adminquery = 'TRUNCATE TABLE admin_table'
    connection.query(adminquery,(err, results)=>{
        if(err){
            console.error("erorr deleting all records", err)
            return;
        }
        console.log("Delected All Records Successfully")
        res.redirect("/")
    })
    
})

app.post("/deleteCustomer",(req, res) =>{
    const {customer_id}  = req.body;
    const query = "DELETE FROM customer WHERE Customer_id = ?";
    connection.query(query, [customer_id],(err, record)=>{
        if(err){
            console.error("Cannot Delete Customer Record", err)
            return;
        }
        console.log("Delete Customer Record")
        res.redirect("/view")
    })
})


app.post("/deleteAdmin",(req, res) =>{
    const {Admin_id}  = req.body;
    console.log(Admin_id)
    const query = "DELETE FROM admin_table WHERE Admin_id = ?";
    connection.query(query, [Admin_id],(err, record)=>{
        if(err){
            console.error("Cannot Delete Admin Record", err)
            return;
        }
        console.log("Delete Admin Record")
        res.redirect("/")
    })
})

app.post("/adminsearch",(req, res) =>{
    const {Admin_id}  = req.body;
    const query = "SELECT * FROM admin_table WHERE Admin_id = ?";
    connection.query(query, [Admin_id],(err, record)=>{
        if(err){
            console.error("erorr inserting data into databae", err)
            return;
        }
        
        res.render("./adminDetail/updateAdmin", {record})
    })
})

app.post("/viewUpdatedAdmin",(req, res) =>{
    const UpdateQuery = 'UPDATE admin_table SET Surname = ?, firstname = ?, email = ?, password = ?, username = ? WHERE Admin_id = ?';

    // Destructure the values from req.body (make sure to match the field names correctly)
    const { surName, firstName, password, email, username, Admin_id} = req.body;
   
    // Ensure the values are passed in the correct order (matching the placeholders)
    
    connection.query(UpdateQuery, [surName, firstName,password, username, email,Admin_id], (err, results) => {

    if (err) {
        console.error('Error updating the record', err);
    }
      console.log('Record updated successfully'); 
      res.redirect("/user/admin")
    });
})

								
passport.use("customer-local",new LocalStrategy({usernameField: 'email'},								
    (email, password, done) => {									
      // Query to find user by username									
      connection.query('SELECT * FROM customer WHERE email = ?', [email], (err, results) => {									
        if (err) return done(err);									
        if (results.length === 0) return done(null, false, { message: 'Incorrect email.' });									
                                      
        const customer = results[0];									
        
    if (!customer.Customer_id) {
      console.log('Customer_Id missing in customer object:', customer);  // Debugging log
      return done(new Error('Customer_Id is missing'));
    }                 
        // Verify password with bcrypt (using callback-style)									
        bcrypt.compare(password, customer.password, (err, isMatch) => {									
          if (err) return done(err);									
          if (isMatch) {									
            return done(null, customer);							
          } else {	
            console.log("incorrect password")								
            return done(null, false, { message: 'Incorrect password.' });									
          }									
        });									
      });									
    }									
));	


passport.use("admin-local",new LocalStrategy(								
    (username, password, done) => {									
      // Query to find user by username									
      connection.query('SELECT * FROM admin_table WHERE username  = ?', [username], (err, results) => {									
        if (err) return done(err);									
        if (results.length === 0) return done(null, false, { message: 'Incorrect email.' });									
                                      
        const admin = results[0];									
        
    if (!admin.Admin_id) {
      console.log('Admin_Id missing in user object:', admin);  // Debugging log
      return done(new Error('Admin_Id is missing'));
    }                 
        // Verify password with bcrypt (using callback-style)									
        bcrypt.compare(password, admin.password, (err, isMatch) => {									
          if (err) return done(err);									
          if (isMatch) {									
            return done(null, admin);							
          } else {	
            console.log("incorrect password")								
            return done(null, false, { message: 'Incorrect password.' });									
          }									
        });									
      });									
    }									
));									

                                      
  // Serialize user into session									
passport.serializeUser((user, done) => {									
    done(null, user.Customer_id || user.Admin_id);
    console.log('Serializing user:', user);  // Log the entire user object
    console.log('admin_id:', user.Admin_id);
    console.log('customer:', user.Customer_id);									
});									
                                      
  // Deserialize user from session									
passport.deserializeUser((id, done) => {
    connection.query('SELECT * FROM customer WHERE Customer_Id = ?', [id], (err, results) => {
        if (err) return done(err); 
        done(null, results[0]) // Log the error for debugging
        
        connection.query('SELECT * FROM admin_table WHERE Admin_id = ?', [id], (err, results) => {
            if (err) return done(err); 
            done(null, results[0]) // Log the error for debugging
        });
  });		
 
});

app.post("/user/login", passport.authenticate("customer-local",{
    successRedirect: '/dashboard',					
    failureRedirect: '/user/login',	
    failureFlash: false,
    successFlash: "welcome back"	
}))
			
// Protected route (dashboard)				
app.get('/dashboard', (req, res) => {				
  if (!req.isAuthenticated()) {				
    return res.redirect('/user/login');				
  }				
  res.render("customerInterface",{user:req.user})				
});				

// Logout route					
app.get('/logout', (req, res) => {			
    req.logout((err) => {					
      if (err) {					
        return res.status(500).send('Error logging out');					
      }					
      res.redirect("/user/login");					
    });					
});					
 
                                 

  // Deserialize user from session									

app.post("/admin/login", passport.authenticate("admin-local",{
    successRedirect: '/user/admin',					
    failureRedirect: '/user/login',	
    failureFlash: true,
    successFlash: "welcome back"				
    
}))
			
// Protected route (dashboard)				
app.get('/user/admin', (req, res) => {				
  if (!req.isAuthenticated()) {				
    return res.redirect('/user/login');				
  }				
  res.render("index")				
});		

app.get('/Adminlogout', (req, res) => {			
    req.logout((err) => {					
      if (err) {					
        return res.status(500).send('Error logging out');					
      }			
      	
      res.redirect("/user/login");					
    });					
});					
 



app.listen(port, ()=>{
    console.log("server is running in PORT", port)
})